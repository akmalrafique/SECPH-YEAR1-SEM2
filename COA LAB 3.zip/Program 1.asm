INCLUDE irvine32.inc
.data

titleMsg BYTE "Calculate Perimeter 2-Hexagon (LOOP and ADD instructions):",0
prompt1 BYTE "Input Hexagon 1 (side length):",0
prompt2 BYTE "Input Hexagon 2 (side length):",0
resMsg BYTE "Result of Perimeter Hexagon 1 and 2:",0
totalMsg BYTE "Total Perimeter Hexagon 1 and 2:",0

sideHex1	DWORD ?
sideHEX2	DWORD ?
Perimeter_hexagon1	DWORD ?
Perimeter_hexagon2	DWORD ?
Total Perimeter	DWORD ?

.code
main PROC

	mov edx, OFFSET titleMsg
	call WriteString
	call Crlf
	call Crlf

	mov edx, OFFSET prompt1
	call WriteString
	call ReadDec
	mov sideHex1, eax

	mov edx, OFFSET prompt2
	call WriteString
	call ReadDec
	mov sideHex2, eax
	call Crlf

	mov ecx, 6
	mov eax, 0
L1:
	add eax, sideHex1
	loop L1
	mov Perimeter_hexagon1, eax

	mov ecx, 6
	mov eax, 0
L2:
	add eax, sideHex2
	loop L2
	mov Perimeter_hexagon2, eax

	mov eax, Perimeter_hexagon1
	add eax, Perimeter_hexagon2
	mov TotalPerimeter, eax

	mov edx, OFFSET resMsg
	call WriteString
	call Crlf

	mov eax, Perimeter_hexagon1
	call WriteDec
	call Crlf

	mov eax, Perimeter_hexagon2
	call WriteDec
	call Crlf
	call Crlf

	mov edx,OFFSET totalMsg
	call WriteString
	mov eax, TotalPerimeter
	call WriteDec
	call Crlf

	exit

main ENDP
END main

