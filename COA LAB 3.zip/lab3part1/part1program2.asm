INCLUDE Irvine32.inc

.data
titleMsg BYTE "calculate sum(unsign INT) INDEX (ODD OR EVEN ) in array HEllo[6] :",0
prompt BYTE "Integer input : ",0
resMsg BYTE "Result Sum hello[index] : ",0
evenMsg BYTE "SUM Hello[even] index location : ",0
oddMsg BYTE " Sum Hello[odd] index location : ",0
HELLO  DWORD 6 DUP(?)
TotalEVEN DWORD 0
TotalODD DWORD 0

.code
main PROC
mov edx,OFFSET titleMsg
call WriteString
call Crlf
call Crlf

mov ecx, 6
mov esi ,OFFSET HELLO
INPUT_LOOP:
mov edx,OFFSET prompt
call WriteString
call ReadDec
mov[esi],eax
add esi,4
loop INPUT_LOOP
call Crlf

mov esi ,OFFSET HELLO
mov ecx,3
mov eax,0
EVEN_LOOP:
add eax ,[esi]
add esi,8
loop EVEN_LOOP
mov TotalEVEN,eax

mov esi,OFFSET HELLO
add esi,4
mov ecx,3
mov eax,0
ODD_LOOP:
add eax,[esi]
add esi,8
loop ODD_LOOP
mov TotalODD,eax

mov edx,OFFSET resMsg
call WriteString
call Crlf
call Crlf
mov edx,OFFSET evenMsg
call WriteString
mov eax ,TotalEVEN
call WriteDec
call crlf
mov edx, OFFSET oddMsg
call WriteString
mov eax,TotalODD
call WriteDec
call Crlf

exit
main ENDP
END main




























































