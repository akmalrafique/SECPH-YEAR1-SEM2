INCLUDE Irvine32.inc

.data

; Shared Menu Strings

menuTitle   BYTE "Welcome to Simple Math Activities :", 0
menuSub     BYTE "Main Menu : ", 0
menuOpt1    BYTE "1. To calculate Perimeter Hexagon (Loop and ADD instructions)", 0
menuOpt2    BYTE "2. To calculate SUM (unsign int) index [Odd or Even] in an Array Hello [6]", 0
menuPrompt  BYTE "Select Your Input : ", 0
loopPrompt  BYTE "Press 'y' to Main Menu or 'n' to Exit the benchmark : ", 0
byeMsg      BYTE "Thank you ... BYE!!", 0

; Variables

titleMsg1   BYTE "Calculate Perimeter 2-Hexagon (LOOP and ADD instructions) :", 0
prompt1     BYTE "Input Hexagon 1 (side length) : ", 0
prompt2     BYTE "Input Hexagon 2 (side length) : ", 0
resMsg1     BYTE "Result of Perimeter Hexagon 1 and 2:", 0
totalMsg    BYTE "Total Perimeter Hexagon 1 and 2: ", 0

titleMsg2   BYTE "Calculate SUM (unsign INT) index (Odd or Even) in array Hello[6] :", 0
prompt      BYTE "Integer input : ", 0
resMsg2     BYTE "Result Sum Hello[index]:", 0
evenMsg     BYTE "Sum Hello[even] index location : ", 0
oddMsg      BYTE "Sum Hello[odd] index location : ", 0

sideHex1           DWORD ?
sideHex2           DWORD ?
Perimeter_hexagon1 DWORD ?
Perimeter_hexagon2 DWORD ?
TotalPerimeter     DWORD ?

HELLO              DWORD 6 DUP(? )
TotalEVEN          DWORD 0
TotalODD           DWORD 0

.code
main PROC

show_menu :
call Clrscr
mov edx, OFFSET menuTitle
call WriteString
call Crlf
call Crlf

mov edx, OFFSET menuSub
call WriteString
call Crlf
call Crlf

mov edx, OFFSET menuOpt1
call WriteString
call Crlf
mov edx, OFFSET menuOpt2
call WriteString
call Crlf
call Crlf

mov edx, OFFSET menuPrompt
call WriteString
call ReadDec

cmp eax, 1
je periHex_loopAdd
cmp eax, 2
je calSum_oddeven
jmp show_menu

; Program 1

periHex_loopAdd:
call Clrscr
mov edx, OFFSET titleMsg1
call WriteString
call Crlf
call Crlf

mov edx, OFFSET prompt1
call WriteString
call ReadDec
mov sideHex1, eax

mov edx, OFFSET prompt2
call WriteString
call ReadDec
mov sideHex2, eax
call Crlf

mov ecx, 6
mov eax, 0
L1: add eax, sideHex1
loop L1
mov Perimeter_hexagon1, eax

mov ecx, 6
mov eax, 0
L2 : add eax, sideHex2
loop L2
mov Perimeter_hexagon2, eax

mov eax, Perimeter_hexagon1
add eax, Perimeter_hexagon2
mov TotalPerimeter, eax

mov edx, OFFSET resMsg1
call WriteString
call Crlf
mov eax, Perimeter_hexagon1
call WriteDec
call Crlf
mov eax, Perimeter_hexagon2
call WriteDec
call Crlf
call Crlf
mov edx, OFFSET totalMsg
call WriteString
mov eax, TotalPerimeter
call WriteDec
call Crlf
call Crlf
jmp ask_continue

; Program 2

calSum_oddeven:
call Clrscr
mov edx, OFFSET titleMsg2
call WriteString
call Crlf
call Crlf

mov ecx, 6
mov esi, OFFSET HELLO
INPUT_LOOP :
mov edx, OFFSET prompt
call WriteString
call ReadDec
mov[esi], eax
add esi, 4
loop INPUT_LOOP
call Crlf

mov esi, OFFSET HELLO
mov ecx, 3
mov eax, 0
EVEN_LOOP:
add eax, [esi]
add esi, 8
loop EVEN_LOOP
mov TotalEVEN, eax

mov esi, OFFSET HELLO
add esi, 4
mov ecx, 3
mov eax, 0
ODD_LOOP:
add eax, [esi]
add esi, 8
loop ODD_LOOP
mov TotalODD, eax

mov edx, OFFSET resMsg2
call WriteString
call Crlf
call Crlf
mov edx, OFFSET evenMsg
call WriteString
mov eax, TotalEVEN
call WriteDec
call Crlf
mov edx, OFFSET oddMsg
call WriteString
mov eax, TotalODD
call WriteDec
call Crlf
call Crlf

; Navigation

ask_continue :
mov edx, OFFSET loopPrompt
call WriteString
call ReadChar
call WriteChar
call Crlf
call Crlf

cmp al, 'y'
je show_menu
cmp al, 'n'
je exit_program
jmp ask_continue

exit_program :
mov edx, OFFSET byeMsg
call WriteString
call Crlf
exit

main ENDP
END main