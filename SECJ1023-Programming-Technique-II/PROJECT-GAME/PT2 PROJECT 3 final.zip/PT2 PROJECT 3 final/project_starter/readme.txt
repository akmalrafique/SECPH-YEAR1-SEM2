Organize your project code using the following folder structure:
[assets]
Contains all media resources such as:
  - images
  - audio files
  - video files

[src]
Contains all source code files
 - Organize code by class
 - Each class should have its own folder containing:
    - .hpp file (class declaration)
    - .cpp file (class implementation)

Example Project Structure:

[project]
 ├── [assets]
 │     ├── dies.wav
 │     ├── heart.jpg
 │
 ├── [src]
 │     ├── main.cpp
 │     ├── [utils]
 │     │     ├── [point]
 │     │     │     ├── point.hpp
 │     │     │     ├── point.cpp
 │     │     │
 │     │     ├── [math]
 │     │           ├── math.hpp
 │     │           ├── math.cpp
 │     │
 │     ├── [player]
 │     │     ├── player.hpp
 │     │     ├── player.cpp
 │     │
 │     ├── [characters]
 │           ├── [collectible]
 │           │     ├── collectible.hpp
 │           │     ├── collectible.cpp
 │           │
 │           ├── [enemy]
 │                 ├── enemy.hpp
 │                 ├── enemy.cpp

- To run the program, use "Multi-file Graphic project" settings