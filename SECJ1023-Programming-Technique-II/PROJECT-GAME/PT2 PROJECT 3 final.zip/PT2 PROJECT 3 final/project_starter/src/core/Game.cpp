#include "Game.hpp"
#include <graphics.h>
#include <cstdlib>
#include <ctime>

Game::Game() {
    gameState = 0;
    srand(time(0));
}

Game::~Game() {
    for (auto bug : swarm) delete bug;
    swarm.clear();
}

void Game::spawnInsect() {
    int currentSpawnRate = 30 - (player.getScore() / 50);
    if (currentSpawnRate < 8) currentSpawnRate = 8; 

    if (rand() % currentSpawnRate == 0) { 
        int startX = 50 + rand() % 500;
        int speedBoost = player.getScore() / 150;
        
        swarm.push_back(new Insect(startX, 0, 3 + speedBoost, 1, 10, BROWN));
    }
}

void Game::checkCollisions() {
    if (gameState == 0) { 

        player.processInput(swarm);
        
    } else if (gameState == 1) { 

        if (ismouseclick(WM_LBUTTONDOWN)) {
            int mx, my;
            getmouseclick(WM_LBUTTONDOWN, mx, my);
            
            int action = ui.checkButtonClicks(mx, my);
            if (action == 1) resetGame();
            else if (action == 2) exit(0);
            
            clearmouseclick(WM_LBUTTONDOWN);
        }
    }
}

void Game::updateScreen() {
    if (gameState == 0) {
        cleardevice();
        setfillstyle(SOLID_FILL, LIGHTGREEN);
        bar(0, 0, 600, 800); 

        spawnInsect();

        for (int i = 0; i < swarm.size(); i++) {
            if (swarm[i]->isAlive()) {
                swarm[i]->move();
                swarm[i]->draw();
                
                if (swarm[i]->getY() > 750) {
                    if (swarm[i]->getPoints() > 0) player.reduceLife(); 
                    swarm[i]->setDead();
                }
            }
        }

        ui.drawHUD(player.getScore(), player.getLives());
        
        if (player.getLives() <= 0) gameState = 1; 

    } else if (gameState == 1) {
        ui.drawGameOverScreen(player.getScore());
    }
}

void Game::resetGame() {
    for (auto bug : swarm) delete bug; 
    swarm.clear();
    player.resetStats(); 
    gameState = 0;
}

void Game::run() {
    initwindow(600, 800, "One Last Picnic"); 
    while (true) {
        checkCollisions();
        updateScreen();
        delay(30); 
    }
    closegraph();
}