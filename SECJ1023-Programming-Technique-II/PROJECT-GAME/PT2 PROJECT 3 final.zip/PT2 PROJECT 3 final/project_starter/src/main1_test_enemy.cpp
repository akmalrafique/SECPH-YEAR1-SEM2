#include <graphics.h>
#include "bugs/Insect.hpp"

int main() {
    initwindow(600, 800, "Testing Parent Enemy Class");
   
    Insect testBug(300, 50, 5, 1, 10, GREEN); 

    while (!kbhit()) { 
        cleardevice();
        testBug.move();
        testBug.draw();
        delay(30);
    }
    closegraph();
    return 0;
}