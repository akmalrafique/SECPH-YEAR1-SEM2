#include <graphics.h>
#include "ui/Scoreboard.hpp"

int main() {
    initwindow(600, 800, "Testing Scoreboard UI");
    Scoreboard testUI;
    
    testUI.drawGameOverScreen(9999); 
    
    while (!kbhit()) { delay(100); }
    closegraph();
    return 0;
}