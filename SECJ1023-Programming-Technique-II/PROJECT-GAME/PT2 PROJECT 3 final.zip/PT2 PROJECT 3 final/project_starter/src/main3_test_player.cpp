#include <graphics.h>
#include <string>
#include <vector> 
#include "player/Player.hpp"
#include "bugs/Insect.hpp"

using namespace std;

int main() {
    initwindow(500, 400, "Testing Player Input Logic");
    
    Player testPlayer;
    vector<Insect*> testSwarm;
    
    Insect* testBug = new Insect(250, 200, 0, 1, 50, GREEN);
    testSwarm.push_back(testBug); 

    while (kbhit() == false) { 
        cleardevice();
        
        setcolor(WHITE);
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        outtextxy(20, 20, (char*)"Click the GREEN BUG!");
        
        string scoreText = "Score: " + to_string(testPlayer.getScore());
        if (testPlayer.getScore() == 50) {
            setcolor(LIGHTGREEN); 
        }
        outtextxy(20, 60, (char*)scoreText.c_str());

        for (int i = 0; i < testSwarm.size(); i++) {
            Insect* bug = testSwarm[i];
            if (bug->isAlive() == true) {
                bug->draw();
            }
        }

        testPlayer.processInput(testSwarm);

        delay(30);
    }
    
    for (int i = 0; i < testSwarm.size(); i++) {
        delete testSwarm[i];
    }
    testSwarm.clear();
    
    closegraph();
    return 0;
}