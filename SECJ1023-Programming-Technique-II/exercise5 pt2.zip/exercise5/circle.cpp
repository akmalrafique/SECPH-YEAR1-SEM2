#include <graphics.h>
#include<cmath>

#include "circle.hpp"

Circle::Circle(int _x, int _y, int _radius): radius(_radius) {}

void Circle::draw(){
    if(selected)
    {
        setcolor(YELLOW);
    }
    else
    {
        setcolor(WHITE);
    }
    circle(x,y,radius);
}
bool Circle:: isInside(int mx, int my){
    double d= sqrt(pow(mx-x,2) + pow(my - y,2));
    return d<= radius;
}
void Circle::resize(int change){
    radius += change;
    if (radius <5) 
    radius =5;
}
void Circle::move(int dx, int dy){
    x+= dx;
    y+= dy;
}