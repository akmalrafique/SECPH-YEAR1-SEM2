#ifndef CIRCLE_H
#define CIRCLE_H
#include "shape.hpp"

class Circle: public Shape
{
protected:
    int radius;

public:
    Circle(int _x = 0, int _y = 0, int _radius = 0);

    void draw() override;
    bool isInside(int mx, int my) override;
    void resize(int change) override;
    void move(int dx, int dy) override;
};

#endif