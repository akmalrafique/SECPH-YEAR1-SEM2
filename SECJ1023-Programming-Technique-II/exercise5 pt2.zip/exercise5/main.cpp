// ? EXERCISE 5: POLYMORPHISM

// Programming Technique II
// Semester 2, 2021/2022

// Section: 01
// Member 1's Name: Akmal Rafique Bin Ahmad Raphaie   Location: KTR K11 (i.e. where are you currently located)
// Member 2's Name: Muhammad Najmi Shahmi Bin Mohd Latpi    Location: KTR K11 

// Log the time(s) your pair programming sessions
//  Date         Time (From)   To             Duration (in minutes)
//  18/6/2026    11:33pm       1:50    ________
//  _________    ___________   ___________    ________

// Video link:
//   https://drive.google.com/drive/folders/1L8SACI-sBgkdGCa35ieDcOiss0S4Bw7r?usp=drive_link




#include <graphics.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>

#include "shape.hpp"
#include "circle.hpp"
#include "rect.hpp"

using namespace std;

// ? Notes: Choose the debug mode "Multi-File Graphic Project" to run this program.

// You may change the max size of the list
#define COUNT 5

int main()
{
	int width = getmaxwidth();
	int height = getmaxheight();
	initwindow(width, height, "Exercise 5");

	/* initialize random seed: */
	srand(time(NULL));


	Shape* shapes[COUNT];

	for(int i=0;i<COUNT;++i){
		int type = rand()% 2;
		int startX = rand() % (width -200)+ 100;
		int startY = rand() % (height -200)+100;
		if (type==0){
			int r = rand() % 40+20;
			shapes[i]= new Circle(startX,startY,r);
		}
		else {
			int w = rand()% 80 +40;
			int h = rand()% 80 +40;
			shapes[i]= new Rect(startX,startY,w,h);
		}
	}


	


	char ch = 0;
	Shape* selectedShape = nullptr;

	while (ch != 27)  // 27 is ESC key
	{
		cleardevice();
		for(int i=0;i<COUNT;++i){
			shapes[i]->draw();
		}

		delay(30);
		if (kbhit())
		{
			ch = getch();
			if(ch ==0 )ch = getch();

			if(selectedShape != nullptr)
			{
			switch (toupper(ch))
			{
			case '+':
			case '=':
				selectedShape->resize(5);
				break;

			case '-':
			case '_':
				selectedShape->resize(-5);
				break;

			case KEY_LEFT:
				selectedShape->move(-10,0);
				break;

			case KEY_RIGHT:
				selectedShape->move(10,0);
				break;

			case KEY_UP:
				selectedShape->move(0,-10);
				break;

			case KEY_DOWN:
				selectedShape->move(0,10);
				break;
			}
		}
	}		
		if (ismouseclick(WM_LBUTTONDOWN))
		{
			int mx, my;
			getmouseclick(WM_LBUTTONDOWN, mx, my);

			for(int i = COUNT - 1; i>=0; --i){
				if(shapes[i]->isInside(mx,my)){
					if(shapes[i]->isSelected()){
						shapes[i]->setSelected(false);
						selectedShape= nullptr;}
							else{
								if(selectedShape != nullptr) {
									selectedShape->setSelected(false);
								}

								shapes[i]->setSelected(true);
								selectedShape=shapes[i];
							}
							break;
						}
					}
				}
			}
			
			for(int i=0;i<COUNT;i++){
				delete shapes[i];
			}
			closegraph();
			
		
	
	return 0;
}