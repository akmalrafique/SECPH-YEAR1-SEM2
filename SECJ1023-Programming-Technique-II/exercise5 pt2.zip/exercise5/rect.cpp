#include <graphics.h>

#include "shape.hpp"
#include "rect.hpp"

Rect::Rect(int _x, int _y, int _width, int _height) : width(_width), height(_height) {}

void Rect::draw(){
    if(selected ){
        setcolor(YELLOW);
    }
    else{
        setcolor(WHITE);
    }
    rectangle(x,y, x+ width,y + height );
}
bool Rect::isInside(int mx,int my){

    return (mx>= x && mx <=x + width && my >= y && my <= y+ height);
}
void Rect::resize(int change){
    width+= change;
    height+= change;
    if(width<10)width =10;
    if (height<10)height =10;
}
void Rect::move(int dx,int dy){
    x+=dx;
    y+=dy;
}