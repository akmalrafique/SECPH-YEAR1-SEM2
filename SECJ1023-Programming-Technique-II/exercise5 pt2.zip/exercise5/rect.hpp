#ifndef RECT_H
#define RECT_H
#include "shape.hpp"
class Rect : public Shape
{
protected:
    int width, height;

public:
    Rect(int _x = 0, int _y = 0, int _width = 0, int _height=0);
    void draw()override;
    bool isInside (int mx,int my)override;
    void resize (int  change) override;
    void move (int dx,int dy )override;
   
};

#endif