#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
protected:
	int x, y;       // for location
	bool selected;  // to indicate whether the shape is selected or not
	
public:
	Shape(int _x = 0, int _y = 0);
	virtual ~ Shape(){}
	void setLocation(int _x, int _y);
	void setSelected(bool _selected);
	bool isSelected()const { return selected;}
	virtual void draw()= 0;
	virtual bool isInside(int mx,int my) =0;
	virtual void resize(int change) =0;
	virtual void move(int dx,int dy)=0;
};

#endif