include irvine32.inc
.data
Rval DWORD ?
Xval DWORD 26
Yval DWORD 30
Zval DWORD 40
.code
main proc
mov eax, Xval;
neg eax;
mov ebx, Yval;
sub ebx, Zval;
add eax, ebx;
inc eax;
mov Rval, eax;
exit
main endp
end main
