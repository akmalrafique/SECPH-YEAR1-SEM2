INCLUDE Irvine32.inc

.code
main proc
MOV DX, 0;
MOV AX, 803h;
MOV BL, 10h;
DIV BL; 

call DumpRegs; 
exit
main endp
end main